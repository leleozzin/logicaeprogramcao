﻿namespace Lista03Definitiva
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.lblPesoMarmita = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblValorMarmita = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Purple;
            this.pictureBox1.Location = new System.Drawing.Point(-6, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(805, 453);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // txt1
            // 
            this.txt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1.Location = new System.Drawing.Point(443, 59);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(223, 38);
            this.txt1.TabIndex = 1;
            this.txt1.TextChanged += new System.EventHandler(this.txt1_TextChanged);
            // 
            // lblPesoMarmita
            // 
            this.lblPesoMarmita.AutoSize = true;
            this.lblPesoMarmita.BackColor = System.Drawing.Color.Purple;
            this.lblPesoMarmita.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesoMarmita.Location = new System.Drawing.Point(35, 56);
            this.lblPesoMarmita.Name = "lblPesoMarmita";
            this.lblPesoMarmita.Size = new System.Drawing.Size(389, 39);
            this.lblPesoMarmita.TabIndex = 2;
            this.lblPesoMarmita.Text = "Peso da Marmita em (g)";
            this.lblPesoMarmita.Click += new System.EventHandler(this.lblPesoMarmita_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.Fuchsia;
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(270, 180);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(235, 57);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Valor a Pagar";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblValorMarmita
            // 
            this.lblValorMarmita.AutoSize = true;
            this.lblValorMarmita.BackColor = System.Drawing.Color.Purple;
            this.lblValorMarmita.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorMarmita.Location = new System.Drawing.Point(36, 316);
            this.lblValorMarmita.Name = "lblValorMarmita";
            this.lblValorMarmita.Size = new System.Drawing.Size(237, 33);
            this.lblValorMarmita.TabIndex = 4;
            this.lblValorMarmita.Text = "Valor da Marmita";
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblValorMarmita);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.lblPesoMarmita);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FrmExercicio3";
            this.Text = "Exercicio3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lblPesoMarmita;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblValorMarmita;
    }
}