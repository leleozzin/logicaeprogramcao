﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("colé colé");
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("vo mostra nada não");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("não vai limpar nada, vai continuar sujo");

        }
    }
}
