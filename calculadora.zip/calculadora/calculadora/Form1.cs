﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNum1.Text);
            float valorNumero2 = float.Parse(txtNum2.Text);
            float soma;

            //Processamento - operação 
            soma = valorNumero1 + valorNumero2;

            //Saída 
            MessageBox.Show("A soma é igual a " + soma);





        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNum1.Text);
            float valorNumero2 = float.Parse(txtNum2.Text);
            float subtrair;

            //Processamento - operação 
            subtrair = valorNumero1 - valorNumero2;

            //Saída 
            MessageBox.Show("A subtração é igual a " + subtrair);





        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNum1.Text);
            float valorNumero2 = float.Parse(txtNum2.Text);
            float multiplicar;

            //Processamento - operação 
            multiplicar = valorNumero1 * valorNumero2;

            //Saída 
            MessageBox.Show("O produto é igual a " + multiplicar);
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNum1.Text);
            float valorNumero2 = float.Parse(txtNum2.Text);
            float dividir;

            //Processamento - operação 
            dividir = valorNumero1 / valorNumero2; 

            //Saída 
            MessageBox.Show("O coeficiente é igual a " + dividir);

        }
    }
}
